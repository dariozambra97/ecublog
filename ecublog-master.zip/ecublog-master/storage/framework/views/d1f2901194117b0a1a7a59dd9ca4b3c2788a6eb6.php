<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                <table id="mytable" class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Título</th>
                            <th>descripcion</th>
                            <th>foto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($blog->id); ?></td>
                                <td><?php echo e($blog->titulo); ?></td>
                                <td><?php echo e($blog->descripcion); ?></td>
                                <td><?php echo e($blog->foto); ?></td>
                                <td><a class="btn btn-success" href="/crearBlog/<?php echo e($blog['id']); ?>/edit">Editar</i></a></td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
                </div>
            </div>
        </div> 
        <div class="col-md-4">
            <a class="btn btn-success" href="<?php echo e(url('crearBlog')); ?>">Crear Blog</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tremim/Descargas/ecublog-master/resources/views/home.blade.php ENDPATH**/ ?>