<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <form method="POST" action="/crearBlog/<?php echo e($blog->id); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PATCH'); ?>
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="titulo">Titulo</label>
                            <input type="text" name="titulo" class="form-control" id="titulo" placeholder="Titulo..." value="<?php echo e($blog->titulo); ?>"> 
                        </div> 
                        <div class="form-group">
                            <label for="descripcion">Descripcion</label>
                            <input type="text" name="descripcion" class="form-control" id="descripcion" value="<?php echo e($blog->descripcion); ?>"> 
                        </div> 
                        <div class="form-group">
                            <label for="foto">Foto</label>
                            <input type="text" name="foto" class="form-control" id="foto" value="<?php echo e($blog->foto); ?>"> 
                        </div>                        
                        <div class="form-group pt-2">
                            <input class="btn btn-success" type="submit" value="guardar">
                        </div>

                    </form>
                </div>
            </div>
        </div> 
        <div class="col-md-4">
            <a class="btn btn-success" href="<?php echo e(url('home')); ?>">Regresar</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tremim/Descargas/ecublog-master/resources/views//blog/edit.blade.php ENDPATH**/ ?>