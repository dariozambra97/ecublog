<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <form method="POST" action="/crearBlog" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="titulo">Titulo</label>
                            <input type="text" name="titulo" class="form-control" id="titulo" placeholder="Titulo..." value="<?php echo e(old('titulo')); ?>"> 
                        </div> 
                        <div class="form-group">
                            <label for="descripcion">Descripcion</label>
                            <input type="text" name="descripcion" class="form-control" id="descripcion" value="<?php echo e(old('descripcion')); ?>"> 
                        </div> 
                        <div class="form-group">
                            <label for="foto">Foto</label>
                            <input type="text" name="foto" class="form-control" id="foto"> 
                        </div>                        
                        <div class="form-group pt-2">
                            <input class="btn btn-success" type="submit" value="crear">
                        </div>

                    </form>
                </div>
            </div>
        </div> 
        <div class="col-md-4">
            <a class="btn btn-success" href="<?php echo e(url('home')); ?>">Regresar</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tremim/Descargas/ecublog-master/resources/views/blog/crear.blade.php ENDPATH**/ ?>