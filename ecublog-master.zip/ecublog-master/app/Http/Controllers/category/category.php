<?php

namespace App\Http\Controllers\category;

class category
{
    public $status = false;
    public $category = null;
    public $categories = [];
    public function __construct($data = null)
    {

    }

    public function getAllByStatus()
    {
        # code...
    }
}
